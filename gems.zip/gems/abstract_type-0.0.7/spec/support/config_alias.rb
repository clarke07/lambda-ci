# encoding: utf-8

require 'rbconfig'

::Config = RbConfig unless defined?(::Config)
