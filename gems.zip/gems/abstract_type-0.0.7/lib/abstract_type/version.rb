# encoding: utf-8

module AbstractType

  # Gem version
  VERSION = '0.0.7'.freeze

end # module AbstractType
